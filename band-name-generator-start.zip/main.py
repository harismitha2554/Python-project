print("Welcome to the Band Name Generator.")
city=input("Whats's name of the city you grew up in?\n")
pet=input("What's your pet's name? \n")
print("Your band name could be "+ city+" " + pet+" ")